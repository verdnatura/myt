cmd_Release/obj.target/nodegit/src/functions/free.o := g++ -o Release/obj.target/nodegit/src/functions/free.o ../src/functions/free.cc '-DNODE_GYP_MODULE_NAME=nodegit' '-DUSING_UV_SHARED=1' '-DUSING_V8_SHARED=1' '-DV8_DEPRECATION_WARNINGS=1' '-D_GLIBCXX_USE_CXX11_ABI=1' '-D_FILE_OFFSET_BITS=64' '-D_LARGEFILE_SOURCE' '-D__STDC_FORMAT_MACROS' '-DOPENSSL_NO_PINSHARED' '-DOPENSSL_THREADS' '-DBUILDING_NODE_EXTENSION' -I/home/runner/.cache/node-gyp/22.21.1/include/node -I/home/runner/.cache/node-gyp/22.21.1/src -I/home/runner/.cache/node-gyp/22.21.1/deps/openssl/config -I/home/runner/.cache/node-gyp/22.21.1/deps/openssl/openssl/include -I/home/runner/.cache/node-gyp/22.21.1/deps/uv/include -I/home/runner/.cache/node-gyp/22.21.1/deps/zlib -I/home/runner/.cache/node-gyp/22.21.1/deps/v8/include -I../vendor/libv8-convert -I../vendor/libssh2/include -I../node_modules/@axosoft/nan -I../vendor/libgit2/include  -fPIC -pthread -Wall -Wextra -Wno-unused-parameter -Wall -m64 -O3 -fno-omit-frame-pointer -fno-rtti -fno-exceptions -fno-strict-aliasing -std=gnu++17 -std=c++17 -MMD -MF ./Release/.deps/Release/obj.target/nodegit/src/functions/free.o.d.raw   -c
Release/obj.target/nodegit/src/functions/free.o: ../src/functions/free.cc \
 ../vendor/libgit2/include/git2.h \
 ../vendor/libgit2/include/git2/annotated_commit.h \
 ../vendor/libgit2/include/git2/common.h \
 ../vendor/libgit2/include/git2/repository.h \
 ../vendor/libgit2/include/git2/types.h \
 ../vendor/libgit2/include/git2/buffer.h \
 ../vendor/libgit2/include/git2/oid.h \
 ../vendor/libgit2/include/git2/experimental.h \
 ../vendor/libgit2/include/git2/odb.h \
 ../vendor/libgit2/include/git2/oidarray.h \
 ../vendor/libgit2/include/git2/indexer.h \
 ../vendor/libgit2/include/git2/commit.h \
 ../vendor/libgit2/include/git2/object.h \
 ../vendor/libgit2/include/git2/apply.h \
 ../vendor/libgit2/include/git2/diff.h \
 ../vendor/libgit2/include/git2/tree.h \
 ../vendor/libgit2/include/git2/refs.h \
 ../vendor/libgit2/include/git2/strarray.h \
 ../vendor/libgit2/include/git2/attr.h \
 ../vendor/libgit2/include/git2/blob.h \
 ../vendor/libgit2/include/git2/blame.h \
 ../vendor/libgit2/include/git2/branch.h \
 ../vendor/libgit2/include/git2/buffer.h \
 ../vendor/libgit2/include/git2/cert.h \
 ../vendor/libgit2/include/git2/checkout.h \
 ../vendor/libgit2/include/git2/cherrypick.h \
 ../vendor/libgit2/include/git2/merge.h \
 ../vendor/libgit2/include/git2/checkout.h \
 ../vendor/libgit2/include/git2/index.h \
 ../vendor/libgit2/include/git2/annotated_commit.h \
 ../vendor/libgit2/include/git2/clone.h \
 ../vendor/libgit2/include/git2/remote.h \
 ../vendor/libgit2/include/git2/refspec.h \
 ../vendor/libgit2/include/git2/net.h \
 ../vendor/libgit2/include/git2/transport.h \
 ../vendor/libgit2/include/git2/cert.h \
 ../vendor/libgit2/include/git2/credential.h \
 ../vendor/libgit2/include/git2/pack.h \
 ../vendor/libgit2/include/git2/proxy.h \
 ../vendor/libgit2/include/git2/commit.h \
 ../vendor/libgit2/include/git2/common.h \
 ../vendor/libgit2/include/git2/config.h \
 ../vendor/libgit2/include/git2/credential.h \
 ../vendor/libgit2/include/git2/deprecated.h \
 ../vendor/libgit2/include/git2/attr.h \
 ../vendor/libgit2/include/git2/config.h \
 ../vendor/libgit2/include/git2/blame.h \
 ../vendor/libgit2/include/git2/cherrypick.h \
 ../vendor/libgit2/include/git2/clone.h \
 ../vendor/libgit2/include/git2/describe.h \
 ../vendor/libgit2/include/git2/errors.h \
 ../vendor/libgit2/include/git2/filter.h \
 ../vendor/libgit2/include/git2/rebase.h \
 ../vendor/libgit2/include/git2/trace.h \
 ../vendor/libgit2/include/git2/revert.h \
 ../vendor/libgit2/include/git2/revparse.h \
 ../vendor/libgit2/include/git2/stash.h \
 ../vendor/libgit2/include/git2/status.h \
 ../vendor/libgit2/include/git2/submodule.h \
 ../vendor/libgit2/include/git2/worktree.h \
 ../vendor/libgit2/include/git2/credential_helpers.h \
 ../vendor/libgit2/include/git2/sys/credential.h \
 ../vendor/libgit2/include/git2/common.h \
 ../vendor/libgit2/include/git2/credential.h \
 ../vendor/libgit2/include/git2/describe.h \
 ../vendor/libgit2/include/git2/diff.h \
 ../vendor/libgit2/include/git2/email.h \
 ../vendor/libgit2/include/git2/errors.h \
 ../vendor/libgit2/include/git2/experimental.h \
 ../vendor/libgit2/include/git2/filter.h \
 ../vendor/libgit2/include/git2/global.h \
 ../vendor/libgit2/include/git2/graph.h \
 ../vendor/libgit2/include/git2/ignore.h \
 ../vendor/libgit2/include/git2/index.h \
 ../vendor/libgit2/include/git2/indexer.h \
 ../vendor/libgit2/include/git2/mailmap.h \
 ../vendor/libgit2/include/git2/merge.h \
 ../vendor/libgit2/include/git2/message.h \
 ../vendor/libgit2/include/git2/net.h \
 ../vendor/libgit2/include/git2/notes.h \
 ../vendor/libgit2/include/git2/object.h \
 ../vendor/libgit2/include/git2/odb.h \
 ../vendor/libgit2/include/git2/odb_backend.h \
 ../vendor/libgit2/include/git2/oid.h \
 ../vendor/libgit2/include/git2/pack.h \
 ../vendor/libgit2/include/git2/patch.h \
 ../vendor/libgit2/include/git2/pathspec.h \
 ../vendor/libgit2/include/git2/proxy.h \
 ../vendor/libgit2/include/git2/rebase.h \
 ../vendor/libgit2/include/git2/refdb.h \
 ../vendor/libgit2/include/git2/reflog.h \
 ../vendor/libgit2/include/git2/refs.h \
 ../vendor/libgit2/include/git2/refspec.h \
 ../vendor/libgit2/include/git2/remote.h \
 ../vendor/libgit2/include/git2/repository.h \
 ../vendor/libgit2/include/git2/reset.h \
 ../vendor/libgit2/include/git2/revert.h \
 ../vendor/libgit2/include/git2/revparse.h \
 ../vendor/libgit2/include/git2/revwalk.h \
 ../vendor/libgit2/include/git2/signature.h \
 ../vendor/libgit2/include/git2/stash.h \
 ../vendor/libgit2/include/git2/status.h \
 ../vendor/libgit2/include/git2/submodule.h \
 ../vendor/libgit2/include/git2/tag.h \
 ../vendor/libgit2/include/git2/transport.h \
 ../vendor/libgit2/include/git2/transaction.h \
 ../vendor/libgit2/include/git2/tree.h \
 ../vendor/libgit2/include/git2/types.h \
 ../vendor/libgit2/include/git2/version.h \
 ../vendor/libgit2/include/git2/worktree.h
../src/functions/free.cc:
../vendor/libgit2/include/git2.h:
../vendor/libgit2/include/git2/annotated_commit.h:
../vendor/libgit2/include/git2/common.h:
../vendor/libgit2/include/git2/repository.h:
../vendor/libgit2/include/git2/types.h:
../vendor/libgit2/include/git2/buffer.h:
../vendor/libgit2/include/git2/oid.h:
../vendor/libgit2/include/git2/experimental.h:
../vendor/libgit2/include/git2/odb.h:
../vendor/libgit2/include/git2/oidarray.h:
../vendor/libgit2/include/git2/indexer.h:
../vendor/libgit2/include/git2/commit.h:
../vendor/libgit2/include/git2/object.h:
../vendor/libgit2/include/git2/apply.h:
../vendor/libgit2/include/git2/diff.h:
../vendor/libgit2/include/git2/tree.h:
../vendor/libgit2/include/git2/refs.h:
../vendor/libgit2/include/git2/strarray.h:
../vendor/libgit2/include/git2/attr.h:
../vendor/libgit2/include/git2/blob.h:
../vendor/libgit2/include/git2/blame.h:
../vendor/libgit2/include/git2/branch.h:
../vendor/libgit2/include/git2/buffer.h:
../vendor/libgit2/include/git2/cert.h:
../vendor/libgit2/include/git2/checkout.h:
../vendor/libgit2/include/git2/cherrypick.h:
../vendor/libgit2/include/git2/merge.h:
../vendor/libgit2/include/git2/checkout.h:
../vendor/libgit2/include/git2/index.h:
../vendor/libgit2/include/git2/annotated_commit.h:
../vendor/libgit2/include/git2/clone.h:
../vendor/libgit2/include/git2/remote.h:
../vendor/libgit2/include/git2/refspec.h:
../vendor/libgit2/include/git2/net.h:
../vendor/libgit2/include/git2/transport.h:
../vendor/libgit2/include/git2/cert.h:
../vendor/libgit2/include/git2/credential.h:
../vendor/libgit2/include/git2/pack.h:
../vendor/libgit2/include/git2/proxy.h:
../vendor/libgit2/include/git2/commit.h:
../vendor/libgit2/include/git2/common.h:
../vendor/libgit2/include/git2/config.h:
../vendor/libgit2/include/git2/credential.h:
../vendor/libgit2/include/git2/deprecated.h:
../vendor/libgit2/include/git2/attr.h:
../vendor/libgit2/include/git2/config.h:
../vendor/libgit2/include/git2/blame.h:
../vendor/libgit2/include/git2/cherrypick.h:
../vendor/libgit2/include/git2/clone.h:
../vendor/libgit2/include/git2/describe.h:
../vendor/libgit2/include/git2/errors.h:
../vendor/libgit2/include/git2/filter.h:
../vendor/libgit2/include/git2/rebase.h:
../vendor/libgit2/include/git2/trace.h:
../vendor/libgit2/include/git2/revert.h:
../vendor/libgit2/include/git2/revparse.h:
../vendor/libgit2/include/git2/stash.h:
../vendor/libgit2/include/git2/status.h:
../vendor/libgit2/include/git2/submodule.h:
../vendor/libgit2/include/git2/worktree.h:
../vendor/libgit2/include/git2/credential_helpers.h:
../vendor/libgit2/include/git2/sys/credential.h:
../vendor/libgit2/include/git2/common.h:
../vendor/libgit2/include/git2/credential.h:
../vendor/libgit2/include/git2/describe.h:
../vendor/libgit2/include/git2/diff.h:
../vendor/libgit2/include/git2/email.h:
../vendor/libgit2/include/git2/errors.h:
../vendor/libgit2/include/git2/experimental.h:
../vendor/libgit2/include/git2/filter.h:
../vendor/libgit2/include/git2/global.h:
../vendor/libgit2/include/git2/graph.h:
../vendor/libgit2/include/git2/ignore.h:
../vendor/libgit2/include/git2/index.h:
../vendor/libgit2/include/git2/indexer.h:
../vendor/libgit2/include/git2/mailmap.h:
../vendor/libgit2/include/git2/merge.h:
../vendor/libgit2/include/git2/message.h:
../vendor/libgit2/include/git2/net.h:
../vendor/libgit2/include/git2/notes.h:
../vendor/libgit2/include/git2/object.h:
../vendor/libgit2/include/git2/odb.h:
../vendor/libgit2/include/git2/odb_backend.h:
../vendor/libgit2/include/git2/oid.h:
../vendor/libgit2/include/git2/pack.h:
../vendor/libgit2/include/git2/patch.h:
../vendor/libgit2/include/git2/pathspec.h:
../vendor/libgit2/include/git2/proxy.h:
../vendor/libgit2/include/git2/rebase.h:
../vendor/libgit2/include/git2/refdb.h:
../vendor/libgit2/include/git2/reflog.h:
../vendor/libgit2/include/git2/refs.h:
../vendor/libgit2/include/git2/refspec.h:
../vendor/libgit2/include/git2/remote.h:
../vendor/libgit2/include/git2/repository.h:
../vendor/libgit2/include/git2/reset.h:
../vendor/libgit2/include/git2/revert.h:
../vendor/libgit2/include/git2/revparse.h:
../vendor/libgit2/include/git2/revwalk.h:
../vendor/libgit2/include/git2/signature.h:
../vendor/libgit2/include/git2/stash.h:
../vendor/libgit2/include/git2/status.h:
../vendor/libgit2/include/git2/submodule.h:
../vendor/libgit2/include/git2/tag.h:
../vendor/libgit2/include/git2/transport.h:
../vendor/libgit2/include/git2/transaction.h:
../vendor/libgit2/include/git2/tree.h:
../vendor/libgit2/include/git2/types.h:
../vendor/libgit2/include/git2/version.h:
../vendor/libgit2/include/git2/worktree.h:
