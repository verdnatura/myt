cmd_Release/obj.target/nodegit/src/mailmap.o := g++ -o Release/obj.target/nodegit/src/mailmap.o ../src/mailmap.cc '-DNODE_GYP_MODULE_NAME=nodegit' '-DUSING_UV_SHARED=1' '-DUSING_V8_SHARED=1' '-DV8_DEPRECATION_WARNINGS=1' '-D_GLIBCXX_USE_CXX11_ABI=1' '-D_FILE_OFFSET_BITS=64' '-D_LARGEFILE_SOURCE' '-D__STDC_FORMAT_MACROS' '-DOPENSSL_NO_PINSHARED' '-DOPENSSL_THREADS' '-DBUILDING_NODE_EXTENSION' -I/home/runner/.cache/node-gyp/22.21.1/include/node -I/home/runner/.cache/node-gyp/22.21.1/src -I/home/runner/.cache/node-gyp/22.21.1/deps/openssl/config -I/home/runner/.cache/node-gyp/22.21.1/deps/openssl/openssl/include -I/home/runner/.cache/node-gyp/22.21.1/deps/uv/include -I/home/runner/.cache/node-gyp/22.21.1/deps/zlib -I/home/runner/.cache/node-gyp/22.21.1/deps/v8/include -I../vendor/libv8-convert -I../vendor/libssh2/include -I../node_modules/@axosoft/nan -I../vendor/libgit2/include  -fPIC -pthread -Wall -Wextra -Wno-unused-parameter -Wall -m64 -O3 -fno-omit-frame-pointer -fno-rtti -fno-exceptions -fno-strict-aliasing -std=gnu++17 -std=c++17 -MMD -MF ./Release/.deps/Release/obj.target/nodegit/src/mailmap.o.d.raw   -c
Release/obj.target/nodegit/src/mailmap.o: ../src/mailmap.cc \
 ../node_modules/@axosoft/nan/nan.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node_version.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/uv.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/uv/errno.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/uv/version.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/uv/unix.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/uv/threadpool.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/uv/linux.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/cppgc/common.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8config.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-array-buffer.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-local-handle.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-handle-base.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-internal.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8config.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-object.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-maybe.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-persistent-handle.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-weak-callback-info.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-primitive.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-data.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-value.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-traced-handle.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-container.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-context.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-snapshot.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-isolate.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-callbacks.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-promise.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-debug.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-script.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-memory-span.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-message.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-embedder-heap.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-function-callback.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-microtask.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-statistics.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-unwinder.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-embedder-state-scope.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-date.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-exception.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-extension.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-external.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-function.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-template.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-initialization.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-platform.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-source-location.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-json.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-locker.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-microtask-queue.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-primitive-object.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-proxy.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-regexp.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-typed-array.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-value-serializer.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-version.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8-wasm.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node_version.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node_api.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/js_native_api.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/js_native_api_types.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node_api_types.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node_buffer.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/node_object_wrap.h \
 ../node_modules/@axosoft/nan/nan_callbacks.h \
 ../node_modules/@axosoft/nan/nan_callbacks_12_inl.h \
 ../node_modules/@axosoft/nan/nan_maybe_43_inl.h \
 ../node_modules/@axosoft/nan/nan_converters.h \
 ../node_modules/@axosoft/nan/nan_converters_43_inl.h \
 ../node_modules/@axosoft/nan/nan_new.h \
 ../node_modules/@axosoft/nan/nan_implementation_12_inl.h \
 ../node_modules/@axosoft/nan/nan_persistent_12_inl.h \
 ../node_modules/@axosoft/nan/nan_weak.h \
 ../node_modules/@axosoft/nan/nan_object_wrap.h \
 ../node_modules/@axosoft/nan/nan_private.h \
 ../node_modules/@axosoft/nan/nan_typedarray_contents.h \
 ../node_modules/@axosoft/nan/nan_json.h \
 ../node_modules/@axosoft/nan/nan_scriptorigin.h \
 ../vendor/libgit2/include/git2.h \
 ../vendor/libgit2/include/git2/annotated_commit.h \
 ../vendor/libgit2/include/git2/common.h \
 ../vendor/libgit2/include/git2/repository.h \
 ../vendor/libgit2/include/git2/types.h \
 ../vendor/libgit2/include/git2/buffer.h \
 ../vendor/libgit2/include/git2/oid.h \
 ../vendor/libgit2/include/git2/experimental.h \
 ../vendor/libgit2/include/git2/odb.h \
 ../vendor/libgit2/include/git2/oidarray.h \
 ../vendor/libgit2/include/git2/indexer.h \
 ../vendor/libgit2/include/git2/commit.h \
 ../vendor/libgit2/include/git2/object.h \
 ../vendor/libgit2/include/git2/apply.h \
 ../vendor/libgit2/include/git2/diff.h \
 ../vendor/libgit2/include/git2/tree.h \
 ../vendor/libgit2/include/git2/refs.h \
 ../vendor/libgit2/include/git2/strarray.h \
 ../vendor/libgit2/include/git2/attr.h \
 ../vendor/libgit2/include/git2/blob.h \
 ../vendor/libgit2/include/git2/blame.h \
 ../vendor/libgit2/include/git2/branch.h \
 ../vendor/libgit2/include/git2/buffer.h \
 ../vendor/libgit2/include/git2/cert.h \
 ../vendor/libgit2/include/git2/checkout.h \
 ../vendor/libgit2/include/git2/cherrypick.h \
 ../vendor/libgit2/include/git2/merge.h \
 ../vendor/libgit2/include/git2/checkout.h \
 ../vendor/libgit2/include/git2/index.h \
 ../vendor/libgit2/include/git2/annotated_commit.h \
 ../vendor/libgit2/include/git2/clone.h \
 ../vendor/libgit2/include/git2/remote.h \
 ../vendor/libgit2/include/git2/refspec.h \
 ../vendor/libgit2/include/git2/net.h \
 ../vendor/libgit2/include/git2/transport.h \
 ../vendor/libgit2/include/git2/cert.h \
 ../vendor/libgit2/include/git2/credential.h \
 ../vendor/libgit2/include/git2/pack.h \
 ../vendor/libgit2/include/git2/proxy.h \
 ../vendor/libgit2/include/git2/commit.h \
 ../vendor/libgit2/include/git2/common.h \
 ../vendor/libgit2/include/git2/config.h \
 ../vendor/libgit2/include/git2/credential.h \
 ../vendor/libgit2/include/git2/deprecated.h \
 ../vendor/libgit2/include/git2/attr.h \
 ../vendor/libgit2/include/git2/config.h \
 ../vendor/libgit2/include/git2/blame.h \
 ../vendor/libgit2/include/git2/cherrypick.h \
 ../vendor/libgit2/include/git2/clone.h \
 ../vendor/libgit2/include/git2/describe.h \
 ../vendor/libgit2/include/git2/errors.h \
 ../vendor/libgit2/include/git2/filter.h \
 ../vendor/libgit2/include/git2/rebase.h \
 ../vendor/libgit2/include/git2/trace.h \
 ../vendor/libgit2/include/git2/revert.h \
 ../vendor/libgit2/include/git2/revparse.h \
 ../vendor/libgit2/include/git2/stash.h \
 ../vendor/libgit2/include/git2/status.h \
 ../vendor/libgit2/include/git2/submodule.h \
 ../vendor/libgit2/include/git2/worktree.h \
 ../vendor/libgit2/include/git2/credential_helpers.h \
 ../vendor/libgit2/include/git2/sys/credential.h \
 ../vendor/libgit2/include/git2/common.h \
 ../vendor/libgit2/include/git2/credential.h \
 ../vendor/libgit2/include/git2/describe.h \
 ../vendor/libgit2/include/git2/diff.h \
 ../vendor/libgit2/include/git2/email.h \
 ../vendor/libgit2/include/git2/errors.h \
 ../vendor/libgit2/include/git2/experimental.h \
 ../vendor/libgit2/include/git2/filter.h \
 ../vendor/libgit2/include/git2/global.h \
 ../vendor/libgit2/include/git2/graph.h \
 ../vendor/libgit2/include/git2/ignore.h \
 ../vendor/libgit2/include/git2/index.h \
 ../vendor/libgit2/include/git2/indexer.h \
 ../vendor/libgit2/include/git2/mailmap.h \
 ../vendor/libgit2/include/git2/merge.h \
 ../vendor/libgit2/include/git2/message.h \
 ../vendor/libgit2/include/git2/net.h \
 ../vendor/libgit2/include/git2/notes.h \
 ../vendor/libgit2/include/git2/object.h \
 ../vendor/libgit2/include/git2/odb.h \
 ../vendor/libgit2/include/git2/odb_backend.h \
 ../vendor/libgit2/include/git2/oid.h \
 ../vendor/libgit2/include/git2/pack.h \
 ../vendor/libgit2/include/git2/patch.h \
 ../vendor/libgit2/include/git2/pathspec.h \
 ../vendor/libgit2/include/git2/proxy.h \
 ../vendor/libgit2/include/git2/rebase.h \
 ../vendor/libgit2/include/git2/refdb.h \
 ../vendor/libgit2/include/git2/reflog.h \
 ../vendor/libgit2/include/git2/refs.h \
 ../vendor/libgit2/include/git2/refspec.h \
 ../vendor/libgit2/include/git2/remote.h \
 ../vendor/libgit2/include/git2/repository.h \
 ../vendor/libgit2/include/git2/reset.h \
 ../vendor/libgit2/include/git2/revert.h \
 ../vendor/libgit2/include/git2/revparse.h \
 ../vendor/libgit2/include/git2/revwalk.h \
 ../vendor/libgit2/include/git2/signature.h \
 ../vendor/libgit2/include/git2/stash.h \
 ../vendor/libgit2/include/git2/status.h \
 ../vendor/libgit2/include/git2/submodule.h \
 ../vendor/libgit2/include/git2/tag.h \
 ../vendor/libgit2/include/git2/transport.h \
 ../vendor/libgit2/include/git2/transaction.h \
 ../vendor/libgit2/include/git2/tree.h \
 ../vendor/libgit2/include/git2/types.h \
 ../vendor/libgit2/include/git2/version.h \
 ../vendor/libgit2/include/git2/worktree.h ../src/../include/nodegit.h \
 ../src/../include/lock_master.h ../src/../include/functions/copy.h \
 /home/runner/.cache/node-gyp/22.21.1/include/node/v8.h \
 ../src/../include/mailmap.h ../src/../include/async_baton.h \
 ../src/../include/lock_master.h ../src/../include/nodegit.h \
 ../src/../include/thread_pool.h ../src/../include/async_worker.h \
 ../src/../include/cleanup_handle.h ../src/../include/context.h \
 ../src/../include/tracker_wrap.h ../src/../include/nodegit_wrapper.h \
 ../src/../include/promise_completion.h \
 ../src/../include/reference_counter.h ../src/../include/worker_pool.h \
 ../vendor/libgit2/include/git2/sys/errors.h \
 ../src/../include/../include/typedefs.h \
 ../vendor/libgit2/include/git2/submodule.h \
 ../src/../include/../include/repository.h \
 ../src/../include/../include/async_baton.h \
 ../src/../include/../include/async_worker.h \
 ../src/../include/../include/cleanup_handle.h \
 ../src/../include/../include/context.h \
 ../src/../include/../include/lock_master.h \
 ../src/../include/../include/nodegit_wrapper.h \
 ../src/../include/../include/promise_completion.h \
 ../src/../include/../include/reference_counter.h \
 ../src/../include/../include/worker_pool.h \
 ../src/../include/../include/../include/typedefs.h \
 ../vendor/libgit2/include/git2/sys/repository.h \
 ../vendor/libgit2/include/git2/types.h \
 ../vendor/libgit2/include/git2/oid.h \
 ../src/../include/../include/../include/commit.h \
 ../src/../include/../include/../include/async_baton.h \
 ../src/../include/../include/../include/async_worker.h \
 ../src/../include/../include/../include/cleanup_handle.h \
 ../src/../include/../include/../include/context.h \
 ../src/../include/../include/../include/lock_master.h \
 ../src/../include/../include/../include/nodegit_wrapper.h \
 ../src/../include/../include/../include/promise_completion.h \
 ../src/../include/../include/../include/reference_counter.h \
 ../src/../include/../include/../include/worker_pool.h \
 ../src/../include/../include/../include/../include/typedefs.h \
 ../src/../include/../include/../include/../include/oid.h \
 ../src/../include/../include/../include/../include/async_baton.h \
 ../src/../include/../include/../include/../include/async_worker.h \
 ../src/../include/../include/../include/../include/cleanup_handle.h \
 ../src/../include/../include/../include/../include/context.h \
 ../src/../include/../include/../include/../include/lock_master.h \
 ../src/../include/../include/../include/../include/nodegit_wrapper.h \
 ../src/../include/../include/../include/../include/promise_completion.h \
 ../src/../include/../include/../include/../include/reference_counter.h \
 ../src/../include/../include/../include/../include/worker_pool.h \
 ../src/../include/../include/../include/../include/../include/typedefs.h \
 ../src/../include/../include/../include/../include/signature.h \
 ../src/../include/../include/../include/../include/../include/time.h \
 ../src/../include/../include/../include/../include/../include/async_baton.h \
 ../src/../include/../include/../include/../include/../include/async_worker.h \
 ../src/../include/../include/../include/../include/../include/cleanup_handle.h \
 ../src/../include/../include/../include/../include/../include/context.h \
 ../src/../include/../include/../include/../include/../include/lock_master.h \
 ../src/../include/../include/../include/../include/../include/nodegit_wrapper.h \
 ../src/../include/../include/../include/../include/../include/promise_completion.h \
 ../src/../include/../include/../include/../include/../include/reference_counter.h \
 ../src/../include/../include/../include/../include/../include/worker_pool.h \
 ../src/../include/../include/../include/../include/../include/../include/typedefs.h \
 ../src/../include/../include/../include/../include/../include/repository.h \
 ../src/../include/../include/../include/../include/tree.h \
 ../src/../include/../include/../include/../include/../include/oid.h \
 ../src/../include/../include/../include/../include/../include/tree_update.h \
 ../src/../include/../include/../include/../include/../include/callback_wrapper.h \
 ../src/../include/../include/../include/../include/../include/configurable_class_wrapper.h \
 ../src/../include/../include/../include/../include/../include/v8_helpers.h \
 ../src/../include/../include/../include/../include/../include/../include/oid.h \
 ../src/../include/../include/../include/../include/../include/tree_entry.h \
 ../src/../include/../include/../include/../include/../include/../include/object.h \
 ../src/../include/../include/../include/../include/../include/../include/async_baton.h \
 ../src/../include/../include/../include/../include/../include/../include/async_worker.h \
 ../src/../include/../include/../include/../include/../include/../include/cleanup_handle.h \
 ../src/../include/../include/../include/../include/../include/../include/context.h \
 ../src/../include/../include/../include/../include/../include/../include/lock_master.h \
 ../src/../include/../include/../include/../include/../include/../include/nodegit_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/promise_completion.h \
 ../src/../include/../include/../include/../include/../include/../include/reference_counter.h \
 ../src/../include/../include/../include/../include/../include/../include/worker_pool.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/typedefs.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/oid.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/repository.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/buf.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/async_baton.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/async_worker.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/cleanup_handle.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/context.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/lock_master.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/nodegit_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/promise_completion.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/reference_counter.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/worker_pool.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/typedefs.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/git_buf_converter.h \
 ../vendor/libgit2/include/git2/buffer.h \
 ../src/../include/../include/../include/../include/../include/../include/repository.h \
 ../src/../include/../include/../include/../include/mailmap.h \
 ../src/../include/../include/../include/../include/repository.h \
 ../src/../include/../include/../include/../include/buf.h \
 ../src/../include/../include/../include/../include/commit_create_options.h \
 ../src/../include/../include/../include/../include/../include/signature.h \
 ../src/../include/../include/../include/submodule.h \
 ../src/../include/../include/../include/../include/submodule_update_options.h \
 ../src/../include/../include/../include/../include/callback_wrapper.h \
 ../src/../include/../include/../include/../include/configurable_class_wrapper.h \
 ../src/../include/../include/../include/../include/v8_helpers.h \
 ../src/../include/../include/../include/../include/../include/checkout_options.h \
 ../src/../include/../include/../include/../include/../include/../include/diff_file.h \
 ../src/../include/../include/../include/../include/../include/../include/strarray.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/str_array_converter.h \
 ../src/../include/../include/../include/../include/../include/../include/tree.h \
 ../src/../include/../include/../include/../include/../include/../include/index.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/index_entry.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/callback_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/configurable_class_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/v8_helpers.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/index_time.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/async_baton.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/async_worker.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/callback_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/context.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/reference_counter.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/nodegit_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/configurable_class_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/v8_helpers.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/../include/oid.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/strarray.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/tree.h \
 ../src/../include/../include/../include/../include/../include/../include/checkout_perfdata.h \
 ../src/../include/../include/../include/../include/../include/fetch_options.h \
 ../src/../include/../include/../include/../include/../include/../include/str_array_converter.h \
 ../src/../include/../include/../include/../include/../include/../include/remote_callbacks.h \
 ../src/../include/../include/../include/../include/../include/../include/callback_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/configurable_class_wrapper.h \
 ../src/../include/../include/../include/../include/../include/../include/v8_helpers.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/credential.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/cert.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/indexer_progress.h \
 ../src/../include/../include/../include/../include/../include/../include/proxy_options.h \
 ../src/../include/../include/../include/remote.h \
 ../src/../include/../include/../include/../include/str_array_converter.h \
 ../src/../include/../include/../include/../include/remote_head.h \
 ../src/../include/../include/../include/../include/../include/functions/free.h \
 ../src/../include/../include/../include/../include/remote_callbacks.h \
 ../src/../include/../include/../include/../include/proxy_options.h \
 ../src/../include/../include/../include/../include/strarray.h \
 ../src/../include/../include/../include/../include/remote_connect_options.h \
 ../src/../include/../include/../include/../include/../include/str_array_converter.h \
 ../src/../include/../include/../include/../include/../include/remote_callbacks.h \
 ../src/../include/../include/../include/../include/../include/proxy_options.h \
 ../src/../include/../include/../include/../include/../include/strarray.h \
 ../src/../include/../include/../include/../include/remote_create_options.h \
 ../src/../include/../include/../include/../include/fetch_options.h \
 ../src/../include/../include/../include/../include/refspec.h \
 ../src/../include/../include/../include/../include/push_options.h \
 ../src/../include/../include/../include/../include/indexer_progress.h \
 ../src/../include/../include/../include/commitarray.h \
 ../src/../include/../include/../include/config.h \
 ../src/../include/../include/../include/../include/git_buf_converter.h \
 ../src/../include/../include/../include/../include/config_entry.h \
 ../src/../include/../include/../include/../include/transaction.h \
 ../src/../include/../include/../include/../include/../include/reflog.h \
 ../src/../include/../include/../include/../include/../include/../include/signature.h \
 ../src/../include/../include/../include/../include/../include/../include/reflog_entry.h \
 ../src/../include/../include/../include/../include/../include/../include/../include/signature.h \
 ../src/../include/../include/../include/buf.h \
 ../src/../include/../include/../include/oid.h \
 ../src/../include/../include/../include/reference.h \
 ../src/../include/../include/../include/../include/object.h \
 ../src/../include/../include/../include/index.h \
 ../src/../include/../include/../include/repository_init_options.h \
 ../src/../include/../include/../include/callback_wrapper.h \
 ../src/../include/../include/../include/configurable_class_wrapper.h \
 ../src/../include/../include/../include/v8_helpers.h \
 ../src/../include/../include/../include/odb.h \
 ../src/../include/../include/../include/../include/odb_object.h \
 ../src/../include/../include/../include/../include/../include/wrapper.h \
 ../src/../include/../include/../include/../include/commit_graph.h \
 ../src/../include/../include/../include/worktree.h \
 ../src/../include/../include/../include/../include/worktree_add_options.h \
 ../src/../include/../include/../include/../include/worktree_prune_options.h \
 ../src/../include/../include/../include/refdb.h \
 ../src/../include/../include/../include/annotated_commit.h \
 ../src/../include/../include/../include/../include/reference.h \
 ../src/../include/../include/signature.h ../src/nodegit_wrapper.cc \
 ../src/../include/repository.h ../src/../include/signature.h
../src/mailmap.cc:
../node_modules/@axosoft/nan/nan.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node_version.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/uv.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/uv/errno.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/uv/version.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/uv/unix.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/uv/threadpool.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/uv/linux.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/cppgc/common.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8config.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-array-buffer.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-local-handle.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-handle-base.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-internal.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8config.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-object.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-maybe.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-persistent-handle.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-weak-callback-info.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-primitive.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-data.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-value.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-traced-handle.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-container.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-context.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-snapshot.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-isolate.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-callbacks.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-promise.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-debug.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-script.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-memory-span.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-message.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-embedder-heap.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-function-callback.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-microtask.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-statistics.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-unwinder.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-embedder-state-scope.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-date.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-exception.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-extension.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-external.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-function.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-template.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-initialization.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-platform.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-source-location.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-json.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-locker.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-microtask-queue.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-primitive-object.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-proxy.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-regexp.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-typed-array.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-value-serializer.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-version.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8-wasm.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node_version.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node_api.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/js_native_api.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/js_native_api_types.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node_api_types.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node_buffer.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/node_object_wrap.h:
../node_modules/@axosoft/nan/nan_callbacks.h:
../node_modules/@axosoft/nan/nan_callbacks_12_inl.h:
../node_modules/@axosoft/nan/nan_maybe_43_inl.h:
../node_modules/@axosoft/nan/nan_converters.h:
../node_modules/@axosoft/nan/nan_converters_43_inl.h:
../node_modules/@axosoft/nan/nan_new.h:
../node_modules/@axosoft/nan/nan_implementation_12_inl.h:
../node_modules/@axosoft/nan/nan_persistent_12_inl.h:
../node_modules/@axosoft/nan/nan_weak.h:
../node_modules/@axosoft/nan/nan_object_wrap.h:
../node_modules/@axosoft/nan/nan_private.h:
../node_modules/@axosoft/nan/nan_typedarray_contents.h:
../node_modules/@axosoft/nan/nan_json.h:
../node_modules/@axosoft/nan/nan_scriptorigin.h:
../vendor/libgit2/include/git2.h:
../vendor/libgit2/include/git2/annotated_commit.h:
../vendor/libgit2/include/git2/common.h:
../vendor/libgit2/include/git2/repository.h:
../vendor/libgit2/include/git2/types.h:
../vendor/libgit2/include/git2/buffer.h:
../vendor/libgit2/include/git2/oid.h:
../vendor/libgit2/include/git2/experimental.h:
../vendor/libgit2/include/git2/odb.h:
../vendor/libgit2/include/git2/oidarray.h:
../vendor/libgit2/include/git2/indexer.h:
../vendor/libgit2/include/git2/commit.h:
../vendor/libgit2/include/git2/object.h:
../vendor/libgit2/include/git2/apply.h:
../vendor/libgit2/include/git2/diff.h:
../vendor/libgit2/include/git2/tree.h:
../vendor/libgit2/include/git2/refs.h:
../vendor/libgit2/include/git2/strarray.h:
../vendor/libgit2/include/git2/attr.h:
../vendor/libgit2/include/git2/blob.h:
../vendor/libgit2/include/git2/blame.h:
../vendor/libgit2/include/git2/branch.h:
../vendor/libgit2/include/git2/buffer.h:
../vendor/libgit2/include/git2/cert.h:
../vendor/libgit2/include/git2/checkout.h:
../vendor/libgit2/include/git2/cherrypick.h:
../vendor/libgit2/include/git2/merge.h:
../vendor/libgit2/include/git2/checkout.h:
../vendor/libgit2/include/git2/index.h:
../vendor/libgit2/include/git2/annotated_commit.h:
../vendor/libgit2/include/git2/clone.h:
../vendor/libgit2/include/git2/remote.h:
../vendor/libgit2/include/git2/refspec.h:
../vendor/libgit2/include/git2/net.h:
../vendor/libgit2/include/git2/transport.h:
../vendor/libgit2/include/git2/cert.h:
../vendor/libgit2/include/git2/credential.h:
../vendor/libgit2/include/git2/pack.h:
../vendor/libgit2/include/git2/proxy.h:
../vendor/libgit2/include/git2/commit.h:
../vendor/libgit2/include/git2/common.h:
../vendor/libgit2/include/git2/config.h:
../vendor/libgit2/include/git2/credential.h:
../vendor/libgit2/include/git2/deprecated.h:
../vendor/libgit2/include/git2/attr.h:
../vendor/libgit2/include/git2/config.h:
../vendor/libgit2/include/git2/blame.h:
../vendor/libgit2/include/git2/cherrypick.h:
../vendor/libgit2/include/git2/clone.h:
../vendor/libgit2/include/git2/describe.h:
../vendor/libgit2/include/git2/errors.h:
../vendor/libgit2/include/git2/filter.h:
../vendor/libgit2/include/git2/rebase.h:
../vendor/libgit2/include/git2/trace.h:
../vendor/libgit2/include/git2/revert.h:
../vendor/libgit2/include/git2/revparse.h:
../vendor/libgit2/include/git2/stash.h:
../vendor/libgit2/include/git2/status.h:
../vendor/libgit2/include/git2/submodule.h:
../vendor/libgit2/include/git2/worktree.h:
../vendor/libgit2/include/git2/credential_helpers.h:
../vendor/libgit2/include/git2/sys/credential.h:
../vendor/libgit2/include/git2/common.h:
../vendor/libgit2/include/git2/credential.h:
../vendor/libgit2/include/git2/describe.h:
../vendor/libgit2/include/git2/diff.h:
../vendor/libgit2/include/git2/email.h:
../vendor/libgit2/include/git2/errors.h:
../vendor/libgit2/include/git2/experimental.h:
../vendor/libgit2/include/git2/filter.h:
../vendor/libgit2/include/git2/global.h:
../vendor/libgit2/include/git2/graph.h:
../vendor/libgit2/include/git2/ignore.h:
../vendor/libgit2/include/git2/index.h:
../vendor/libgit2/include/git2/indexer.h:
../vendor/libgit2/include/git2/mailmap.h:
../vendor/libgit2/include/git2/merge.h:
../vendor/libgit2/include/git2/message.h:
../vendor/libgit2/include/git2/net.h:
../vendor/libgit2/include/git2/notes.h:
../vendor/libgit2/include/git2/object.h:
../vendor/libgit2/include/git2/odb.h:
../vendor/libgit2/include/git2/odb_backend.h:
../vendor/libgit2/include/git2/oid.h:
../vendor/libgit2/include/git2/pack.h:
../vendor/libgit2/include/git2/patch.h:
../vendor/libgit2/include/git2/pathspec.h:
../vendor/libgit2/include/git2/proxy.h:
../vendor/libgit2/include/git2/rebase.h:
../vendor/libgit2/include/git2/refdb.h:
../vendor/libgit2/include/git2/reflog.h:
../vendor/libgit2/include/git2/refs.h:
../vendor/libgit2/include/git2/refspec.h:
../vendor/libgit2/include/git2/remote.h:
../vendor/libgit2/include/git2/repository.h:
../vendor/libgit2/include/git2/reset.h:
../vendor/libgit2/include/git2/revert.h:
../vendor/libgit2/include/git2/revparse.h:
../vendor/libgit2/include/git2/revwalk.h:
../vendor/libgit2/include/git2/signature.h:
../vendor/libgit2/include/git2/stash.h:
../vendor/libgit2/include/git2/status.h:
../vendor/libgit2/include/git2/submodule.h:
../vendor/libgit2/include/git2/tag.h:
../vendor/libgit2/include/git2/transport.h:
../vendor/libgit2/include/git2/transaction.h:
../vendor/libgit2/include/git2/tree.h:
../vendor/libgit2/include/git2/types.h:
../vendor/libgit2/include/git2/version.h:
../vendor/libgit2/include/git2/worktree.h:
../src/../include/nodegit.h:
../src/../include/lock_master.h:
../src/../include/functions/copy.h:
/home/runner/.cache/node-gyp/22.21.1/include/node/v8.h:
../src/../include/mailmap.h:
../src/../include/async_baton.h:
../src/../include/lock_master.h:
../src/../include/nodegit.h:
../src/../include/thread_pool.h:
../src/../include/async_worker.h:
../src/../include/cleanup_handle.h:
../src/../include/context.h:
../src/../include/tracker_wrap.h:
../src/../include/nodegit_wrapper.h:
../src/../include/promise_completion.h:
../src/../include/reference_counter.h:
../src/../include/worker_pool.h:
../vendor/libgit2/include/git2/sys/errors.h:
../src/../include/../include/typedefs.h:
../vendor/libgit2/include/git2/submodule.h:
../src/../include/../include/repository.h:
../src/../include/../include/async_baton.h:
../src/../include/../include/async_worker.h:
../src/../include/../include/cleanup_handle.h:
../src/../include/../include/context.h:
../src/../include/../include/lock_master.h:
../src/../include/../include/nodegit_wrapper.h:
../src/../include/../include/promise_completion.h:
../src/../include/../include/reference_counter.h:
../src/../include/../include/worker_pool.h:
../src/../include/../include/../include/typedefs.h:
../vendor/libgit2/include/git2/sys/repository.h:
../vendor/libgit2/include/git2/types.h:
../vendor/libgit2/include/git2/oid.h:
../src/../include/../include/../include/commit.h:
../src/../include/../include/../include/async_baton.h:
../src/../include/../include/../include/async_worker.h:
../src/../include/../include/../include/cleanup_handle.h:
../src/../include/../include/../include/context.h:
../src/../include/../include/../include/lock_master.h:
../src/../include/../include/../include/nodegit_wrapper.h:
../src/../include/../include/../include/promise_completion.h:
../src/../include/../include/../include/reference_counter.h:
../src/../include/../include/../include/worker_pool.h:
../src/../include/../include/../include/../include/typedefs.h:
../src/../include/../include/../include/../include/oid.h:
../src/../include/../include/../include/../include/async_baton.h:
../src/../include/../include/../include/../include/async_worker.h:
../src/../include/../include/../include/../include/cleanup_handle.h:
../src/../include/../include/../include/../include/context.h:
../src/../include/../include/../include/../include/lock_master.h:
../src/../include/../include/../include/../include/nodegit_wrapper.h:
../src/../include/../include/../include/../include/promise_completion.h:
../src/../include/../include/../include/../include/reference_counter.h:
../src/../include/../include/../include/../include/worker_pool.h:
../src/../include/../include/../include/../include/../include/typedefs.h:
../src/../include/../include/../include/../include/signature.h:
../src/../include/../include/../include/../include/../include/time.h:
../src/../include/../include/../include/../include/../include/async_baton.h:
../src/../include/../include/../include/../include/../include/async_worker.h:
../src/../include/../include/../include/../include/../include/cleanup_handle.h:
../src/../include/../include/../include/../include/../include/context.h:
../src/../include/../include/../include/../include/../include/lock_master.h:
../src/../include/../include/../include/../include/../include/nodegit_wrapper.h:
../src/../include/../include/../include/../include/../include/promise_completion.h:
../src/../include/../include/../include/../include/../include/reference_counter.h:
../src/../include/../include/../include/../include/../include/worker_pool.h:
../src/../include/../include/../include/../include/../include/../include/typedefs.h:
../src/../include/../include/../include/../include/../include/repository.h:
../src/../include/../include/../include/../include/tree.h:
../src/../include/../include/../include/../include/../include/oid.h:
../src/../include/../include/../include/../include/../include/tree_update.h:
../src/../include/../include/../include/../include/../include/callback_wrapper.h:
../src/../include/../include/../include/../include/../include/configurable_class_wrapper.h:
../src/../include/../include/../include/../include/../include/v8_helpers.h:
../src/../include/../include/../include/../include/../include/../include/oid.h:
../src/../include/../include/../include/../include/../include/tree_entry.h:
../src/../include/../include/../include/../include/../include/../include/object.h:
../src/../include/../include/../include/../include/../include/../include/async_baton.h:
../src/../include/../include/../include/../include/../include/../include/async_worker.h:
../src/../include/../include/../include/../include/../include/../include/cleanup_handle.h:
../src/../include/../include/../include/../include/../include/../include/context.h:
../src/../include/../include/../include/../include/../include/../include/lock_master.h:
../src/../include/../include/../include/../include/../include/../include/nodegit_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/promise_completion.h:
../src/../include/../include/../include/../include/../include/../include/reference_counter.h:
../src/../include/../include/../include/../include/../include/../include/worker_pool.h:
../src/../include/../include/../include/../include/../include/../include/../include/typedefs.h:
../src/../include/../include/../include/../include/../include/../include/../include/oid.h:
../src/../include/../include/../include/../include/../include/../include/../include/repository.h:
../src/../include/../include/../include/../include/../include/../include/../include/buf.h:
../src/../include/../include/../include/../include/../include/../include/../include/async_baton.h:
../src/../include/../include/../include/../include/../include/../include/../include/async_worker.h:
../src/../include/../include/../include/../include/../include/../include/../include/cleanup_handle.h:
../src/../include/../include/../include/../include/../include/../include/../include/context.h:
../src/../include/../include/../include/../include/../include/../include/../include/lock_master.h:
../src/../include/../include/../include/../include/../include/../include/../include/nodegit_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/../include/promise_completion.h:
../src/../include/../include/../include/../include/../include/../include/../include/reference_counter.h:
../src/../include/../include/../include/../include/../include/../include/../include/worker_pool.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/typedefs.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/git_buf_converter.h:
../vendor/libgit2/include/git2/buffer.h:
../src/../include/../include/../include/../include/../include/../include/repository.h:
../src/../include/../include/../include/../include/mailmap.h:
../src/../include/../include/../include/../include/repository.h:
../src/../include/../include/../include/../include/buf.h:
../src/../include/../include/../include/../include/commit_create_options.h:
../src/../include/../include/../include/../include/../include/signature.h:
../src/../include/../include/../include/submodule.h:
../src/../include/../include/../include/../include/submodule_update_options.h:
../src/../include/../include/../include/../include/callback_wrapper.h:
../src/../include/../include/../include/../include/configurable_class_wrapper.h:
../src/../include/../include/../include/../include/v8_helpers.h:
../src/../include/../include/../include/../include/../include/checkout_options.h:
../src/../include/../include/../include/../include/../include/../include/diff_file.h:
../src/../include/../include/../include/../include/../include/../include/strarray.h:
../src/../include/../include/../include/../include/../include/../include/../include/str_array_converter.h:
../src/../include/../include/../include/../include/../include/../include/tree.h:
../src/../include/../include/../include/../include/../include/../include/index.h:
../src/../include/../include/../include/../include/../include/../include/../include/index_entry.h:
../src/../include/../include/../include/../include/../include/../include/../include/callback_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/../include/configurable_class_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/../include/v8_helpers.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/index_time.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/async_baton.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/async_worker.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/callback_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/context.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/reference_counter.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/nodegit_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/configurable_class_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/v8_helpers.h:
../src/../include/../include/../include/../include/../include/../include/../include/../include/oid.h:
../src/../include/../include/../include/../include/../include/../include/../include/strarray.h:
../src/../include/../include/../include/../include/../include/../include/../include/tree.h:
../src/../include/../include/../include/../include/../include/../include/checkout_perfdata.h:
../src/../include/../include/../include/../include/../include/fetch_options.h:
../src/../include/../include/../include/../include/../include/../include/str_array_converter.h:
../src/../include/../include/../include/../include/../include/../include/remote_callbacks.h:
../src/../include/../include/../include/../include/../include/../include/callback_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/configurable_class_wrapper.h:
../src/../include/../include/../include/../include/../include/../include/v8_helpers.h:
../src/../include/../include/../include/../include/../include/../include/../include/credential.h:
../src/../include/../include/../include/../include/../include/../include/../include/cert.h:
../src/../include/../include/../include/../include/../include/../include/../include/indexer_progress.h:
../src/../include/../include/../include/../include/../include/../include/proxy_options.h:
../src/../include/../include/../include/remote.h:
../src/../include/../include/../include/../include/str_array_converter.h:
../src/../include/../include/../include/../include/remote_head.h:
../src/../include/../include/../include/../include/../include/functions/free.h:
../src/../include/../include/../include/../include/remote_callbacks.h:
../src/../include/../include/../include/../include/proxy_options.h:
../src/../include/../include/../include/../include/strarray.h:
../src/../include/../include/../include/../include/remote_connect_options.h:
../src/../include/../include/../include/../include/../include/str_array_converter.h:
../src/../include/../include/../include/../include/../include/remote_callbacks.h:
../src/../include/../include/../include/../include/../include/proxy_options.h:
../src/../include/../include/../include/../include/../include/strarray.h:
../src/../include/../include/../include/../include/remote_create_options.h:
../src/../include/../include/../include/../include/fetch_options.h:
../src/../include/../include/../include/../include/refspec.h:
../src/../include/../include/../include/../include/push_options.h:
../src/../include/../include/../include/../include/indexer_progress.h:
../src/../include/../include/../include/commitarray.h:
../src/../include/../include/../include/config.h:
../src/../include/../include/../include/../include/git_buf_converter.h:
../src/../include/../include/../include/../include/config_entry.h:
../src/../include/../include/../include/../include/transaction.h:
../src/../include/../include/../include/../include/../include/reflog.h:
../src/../include/../include/../include/../include/../include/../include/signature.h:
../src/../include/../include/../include/../include/../include/../include/reflog_entry.h:
../src/../include/../include/../include/../include/../include/../include/../include/signature.h:
../src/../include/../include/../include/buf.h:
../src/../include/../include/../include/oid.h:
../src/../include/../include/../include/reference.h:
../src/../include/../include/../include/../include/object.h:
../src/../include/../include/../include/index.h:
../src/../include/../include/../include/repository_init_options.h:
../src/../include/../include/../include/callback_wrapper.h:
../src/../include/../include/../include/configurable_class_wrapper.h:
../src/../include/../include/../include/v8_helpers.h:
../src/../include/../include/../include/odb.h:
../src/../include/../include/../include/../include/odb_object.h:
../src/../include/../include/../include/../include/../include/wrapper.h:
../src/../include/../include/../include/../include/commit_graph.h:
../src/../include/../include/../include/worktree.h:
../src/../include/../include/../include/../include/worktree_add_options.h:
../src/../include/../include/../include/../include/worktree_prune_options.h:
../src/../include/../include/../include/refdb.h:
../src/../include/../include/../include/annotated_commit.h:
../src/../include/../include/../include/../include/reference.h:
../src/../include/../include/signature.h:
../src/nodegit_wrapper.cc:
../src/../include/repository.h:
../src/../include/signature.h:
