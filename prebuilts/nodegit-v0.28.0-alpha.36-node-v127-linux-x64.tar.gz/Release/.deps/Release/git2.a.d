cmd_Release/git2.a := ln -f "Release/obj.target/vendor/git2.a" "Release/git2.a" 2>/dev/null || (rm -rf "Release/git2.a" && cp -af "Release/obj.target/vendor/git2.a" "Release/git2.a")
