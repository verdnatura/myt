cmd_Release/pcre.a := ln -f "Release/obj.target/vendor/pcre.a" "Release/pcre.a" 2>/dev/null || (rm -rf "Release/pcre.a" && cp -af "Release/obj.target/vendor/pcre.a" "Release/pcre.a")
