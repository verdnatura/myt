cmd_Release/zlib.a := ln -f "Release/obj.target/vendor/zlib.a" "Release/zlib.a" 2>/dev/null || (rm -rf "Release/zlib.a" && cp -af "Release/obj.target/vendor/zlib.a" "Release/zlib.a")
