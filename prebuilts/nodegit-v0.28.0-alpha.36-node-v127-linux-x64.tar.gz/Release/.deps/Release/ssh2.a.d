cmd_Release/ssh2.a := ln -f "Release/obj.target/vendor/ssh2.a" "Release/ssh2.a" 2>/dev/null || (rm -rf "Release/ssh2.a" && cp -af "Release/obj.target/vendor/ssh2.a" "Release/ssh2.a")
